# Eko Traders Dataset — Module 3 (SQL and Databases)

Synthetic dataset for a fictional Nigerian retail chain, Eko Traders, used
consistently across every artefact in this module: the six topic slide decks
(3.1–3.6), the module and topic demo guides, `schema.sql`, `eko_traders.db`,
and the 50-item MCQ set. Every number cited in any of those files traces back
to these CSVs.

**No real personal data.** All names, phone numbers, addresses and figures
are invented for teaching purposes. Safe to upload to an AI tool for the
3.6 AI-augmented SQL topic.

---

## OLTP tables (3.1–3.4, 3.6)

### `customers.csv` — 10 rows
One row per registered customer.

| Column | Type | Notes |
|---|---|---|
| `customer_id` | integer, primary key | 101–110 |
| `full_name` | text | |
| `city` | text | Lagos, Ibadan, Abuja, Port Harcourt, or Kano |
| `phone` | text, nullable | 2 customers (108, 110) have no phone on file, used to teach `COUNT(*)` vs. `COUNT(column)` in 3.3 |
| `membership_tier` | text | Bronze, Silver, or Gold |
| `total_spent` | integer (₦) | Running total, used throughout 3.2–3.4 |
| `joined_date` | text (YYYY-MM-DD) | |

### `products.csv` — 5 rows
| Column | Type | Notes |
|---|---|---|
| `product_id` | text, primary key | P1–P5 |
| `product_name` | text | |
| `category` | text | Groceries, Electronics, or Snacks |
| `unit_price` | integer (₦) | |

### `orders.csv` — 4 rows
One row per order. Only customers 101, 103 and 104 have orders; customers
102 and 105 have none, used throughout 3.4 and 3.6 to teach LEFT JOIN and
row-count prediction.

| Column | Type | Notes |
|---|---|---|
| `order_id` | integer, primary key | 5001–5004 |
| `customer_id` | integer, foreign key → `customers.customer_id` | |
| `order_date` | text (YYYY-MM-DD) | |
| `status` | text | Delivered or Cancelled |

### `order_items.csv` — 4 rows
One row per product sold within an order (the module's example of table grain
in 3.1).

| Column | Type | Notes |
|---|---|---|
| `order_item_id` | integer, primary key | |
| `order_id` | integer, foreign key → `orders.order_id` | |
| `product_id` | text, foreign key → `products.product_id` | |
| `quantity` | integer | |
| `line_total` | integer (₦) | |

### `payments.csv` — 3 rows
One row per payment against a Delivered order.

| Column | Type | Notes |
|---|---|---|
| `payment_id` | integer, primary key | |
| `order_id` | integer, foreign key → `orders.order_id` | |
| `amount` | integer (₦) | |
| `payment_date` | text (YYYY-MM-DD) | |
| `method` | text | Card or Transfer |

---

## Warehouse / star schema tables (3.5)

### `dim_date.csv` — 4 rows
| Column | Type | Notes |
|---|---|---|
| `date_key` | text, primary key | D1–D4 |
| `full_date` | text (YYYY-MM-DD) | |
| `month` | text | |
| `quarter` | text | "Q1 2026" or "Q2 2026" |
| `year` | integer | |

### `dim_customer.csv` — 10 rows
Denormalised copy of `customers`, description-only (no measures).

### `dim_product.csv` — 5 rows
Denormalised copy of `products`, description-only.

### `fact_sales.csv` — 6 rows
One row per line item sold (the module's worked example of a fact table's
grain in 3.5). Note: `fact_sales` is illustrative, not a literal re-export of
`order_items` — it uses its own small set of sale events to keep the Q1 2026
revenue-by-category numbers (Electronics 43000, Groceries 34000, Snacks 7500)
clean and hand-checkable.

| Column | Type | Notes |
|---|---|---|
| `sale_key` | text, primary key | F1–F6 |
| `date_key` | text, foreign key → `dim_date.date_key` | |
| `customer_key` | integer, foreign key → `dim_customer.customer_key` | |
| `product_key` | text, foreign key → `dim_product.product_key` | |
| `quantity` | integer | |
| `line_total` | integer (₦) | |

---

## One scoping note that matters

Topics 3.2, 3.3 and 3.5 use the **full 10-row `customers` table**. Topics 3.4
and 3.6 deliberately restrict to a **5-customer, 4-order slice**
(`customer_id` 101–105) so join row counts stay hand-countable. `schema.sql`
and `eko_traders.db` both define a `join_demo_customers` view for this; when
working from the CSVs directly, filter `customers.csv` to
`customer_id BETWEEN 101 AND 105` for any 3.4 or 3.6 exercise.

---

## Headline numbers, verified

Every figure below was recomputed directly from these CSVs and cross-checked
against every deck, demo guide and the MCQ answer key before delivery.

| Figure | Value | Cited in |
|---|---|---|
| Customers in Lagos | 3 | 3.2 |
| `COUNT(*)` / `COUNT(phone)` | 10 / 8 | 3.3 |
| `SUM(total_spent)`, all customers | 858000 | 3.3, MCQ |
| Gold tier average spend | 156250 | 3.3, MCQ |
| Customers with `total_spent` > 100000 | 3 | 3.2 |
| INNER JOIN row count (5-customer slice) | 4 | 3.4, MCQ |
| LEFT JOIN row count (5-customer slice) | 6 | 3.4, MCQ |
| Never-ordered customers | Tunde Bakare, Ngozi Eze | 3.4, 3.6 |
| Electronics / Groceries / Snacks revenue, Q1 2026 | 43000 / 34000 / 7500 | 3.5 |
| Unique customers who ordered, Q1 2026 (correct) | 2 | 3.6 |
| Same query with `COUNT(*)` instead of `COUNT(DISTINCT)` (the bug) | 3 | 3.6 |

## Files in this package

- `customers.csv`, `products.csv`, `orders.csv`, `order_items.csv`, `payments.csv`
- `dim_date.csv`, `dim_customer.csv`, `dim_product.csv`, `fact_sales.csv`
- This file (`data-dictionary.md`)

For a ready-to-query database built from these same rows, see `eko_traders.db`
or `schema.sql` from this module's other deliverables.
